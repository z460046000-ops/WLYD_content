# 测试记录

日期：2026-10-14。测试对象为独立项目 `@wlyd/dsh-material-knowledge-assembly@0.1.1`。

| 验证 | 结果与边界 |
|---|---|
| `npm run check` | 五个源码文件语法检查通过 |
| `npm test` | 9/9：原有 7 项，加上能力→场景→问题→趋势的建议关联、未匹配候选不阻断、候选不得冒充已实现能力或编造数字 |
| 原件转换抽查 | 30 页文字 PDF 取到 11670 字；BIP PPTX 取到 31675 字；现有 DOCX 取到 749 字；合成 XLSX 行列提取通过。这里只验证可读文字，不判断视觉、图表或业务事实完整性 |
| 后端只读联调 | 配置账号列出 8 个项目；在可见项目绑定库中找到 6 个 `completed` 文档；`hybrid-search` 返回 6 个片段，首项具备文档 ID、chunk ID 和正文。未打印、打包或提交片段内容 |
| 独立 DSH profile | 初版 `assembly-test`、`wlyd-assembly-acceptance-20261014` 与新版 `wlyd-assembly-011-acceptance` 均从 DSH base 起步；新版 `.tgz` 安装成功，依赖列表显示 `0.1.1`，`--dump-config` 有独立 Cordis ID，未出现旧售前插件或 HTML Anything；初版已从安装包加载并注册 5 个独立工具，新版未重测工具调用 |
| 包白名单 | `npm pack --dry-run`/tar 列表只含 `src/`、`rules/`、`docs/`、README、manifest、Cordis patch；无旧插件源码、goodcase 原件或凭证 |
| 安装包 SHA-256 | 打包后用 `shasum -a 256` 核对，结果单独记录在 `releases/SHA256SUMS` |

## 尚未完成的真实验收

- 未向生产内容中台上传测试材料，因此真实 multipart 接收、解析中/失败/完成、幂等和服务端拒绝尚未联调。自动测试只验证请求构造和状态处理。
- 未在 DSH WebUI 逐键拖入附件、与真实模型对话生成报告；本地模型接口使用合成流验证，报告语义需人工核对。
- 未测试 OCR、DMG 只读提取、旧 Office、音视频、链接抓取；这些在本版返回明确状态或不提供入口。
- 公开资料实时检索未接入；当前“继续检索”只覆盖本次材料和授权知识库。组稿关系为模型建议，尚无真实模型报告的逐条语义人工验收。
- DSH 用户与平台配置账号的身份映射、上传人的后端字段尚无正式契约。`platformUserId` 保持空。
- `npm audit --omit=dev` 检出 5 项中危依赖告警，来源于 `exceljs`、`mammoth` 的传递依赖；未使用可能破坏兼容性的强制降级修复。
